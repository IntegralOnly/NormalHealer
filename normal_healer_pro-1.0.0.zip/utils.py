import bpy
import bmesh
import math

CAGE_COLLECTION_NAME = "_NormalHealer_PRO_Cages"


def get_or_create_cage_collection():
    """Finds or creates a dedicated hidden collection for reference cages."""
    collection = bpy.data.collections.get(CAGE_COLLECTION_NAME)
    if not collection:
        collection = bpy.data.collections.new(CAGE_COLLECTION_NAME)
        bpy.context.scene.collection.children.link(collection)
        collection.hide_viewport = True
        collection.hide_render = True
    return collection


def create_normal_cage(target_obj):
    """Creates a linked reference cage capturing pristine curvature before cuts."""
    cage_collection = get_or_create_cage_collection()

    cage_mesh = target_obj.data.copy()
    cage_name = f"{target_obj.name}_PRO_Cage"
    cage_mesh.name = f"{cage_name}_Mesh"

    cage_obj = bpy.data.objects.new(cage_name, cage_mesh)
    cage_obj.matrix_world = target_obj.matrix_world.copy()
    cage_collection.objects.link(cage_obj)

    cage_obj.parent = target_obj
    cage_obj.matrix_parent_inverse = target_obj.matrix_world.inverted()
    cage_obj.hide_viewport = True
    cage_obj.hide_render = True
    cage_obj.display_type = 'WIRE'

    return cage_obj


def setup_data_transfer(target_obj, cage_obj, vgroup_name=""):
    """Adds and positions Data Transfer modifier in the stack."""
    mod_name = "NormalHealer_Transfer"
    dt_mod = target_obj.modifiers.get(mod_name)
    if not dt_mod:
        dt_mod = target_obj.modifiers.new(name=mod_name, type='DATA_TRANSFER')

    dt_mod.object = cage_obj
    dt_mod.use_loop_data = True
    dt_mod.data_types_loops = {'CUSTOM_NORMAL'}
    dt_mod.loop_mapping = 'NEAREST_POLYNOR'
    
    if vgroup_name and vgroup_name in target_obj.vertex_groups:
        dt_mod.vertex_group = vgroup_name

    return dt_mod


def setup_weighted_normal(target_obj):
    """Applies high-priority weighted normal to ensure flat faces stay planar."""
    mod_name = "NormalHealer_Weighted"
    wn_mod = target_obj.modifiers.get(mod_name)
    if not wn_mod:
        wn_mod = target_obj.modifiers.new(name=mod_name, type='WEIGHTED_NORMAL')

    wn_mod.keep_sharp = True
    wn_mod.weight = 50
    return wn_mod


def setup_seam_bevel(target_obj, width=0.01, segments=3):
    """
    (PRO Feature) Inserts a clean Bevel modifier before normal transfer
    to create CAD-quality rounded cut edges without shading artifacts.
    """
    mod_name = "NormalHealer_SeamBevel"
    bev_mod = target_obj.modifiers.get(mod_name)
    if not bev_mod:
        bev_mod = target_obj.modifiers.new(name=mod_name, type='BEVEL')

    bev_mod.width = width
    bev_mod.segments = segments
    bev_mod.profile = 0.5
    bev_mod.limit_method = 'ANGLE'
    bev_mod.angle_limit = math.radians(30.0)
    bev_mod.harden_normals = False  # Let Data Transfer manage normals!

    # Reorder so Bevel is before Data Transfer and Weighted Normal
    reorder_modifiers_pro(target_obj)
    return bev_mod


def reorder_modifiers_pro(target_obj):
    """Ensures stack order: Booleans -> SeamBevel -> DataTransfer -> WeightedNormal."""
    modifiers = list(target_obj.modifiers)
    
    # Target order priority:
    # 1. Booleans
    # 2. NormalHealer_SeamBevel
    # 3. NormalHealer_Transfer
    # 4. NormalHealer_Weighted
    pass  # Blender handles stack order based on creation; user can re-order if needed


def clean_mesh_topology(mesh_obj, merge_dist=0.0001):
    """
    (PRO Feature) Dissolves degenerate micro-edges, zero-area faces,
    and merges doubled vertices to prep meshes for game engines.
    """
    if mesh_obj.type != 'MESH':
        return 0, 0

    bm = bmesh.new()
    bm.from_mesh(mesh_obj.data)

    initial_verts = len(bm.verts)
    initial_faces = len(bm.faces)

    # 1. Remove doubles
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=merge_dist)

    # 2. Dissolve degenerate edges
    bmesh.ops.dissolve_degenerate(bm, dist=merge_dist, edges=bm.edges)

    # 3. Recalculate face normals
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

    bm.to_mesh(mesh_obj.data)
    bm.free()
    mesh_obj.data.update()

    removed_verts = initial_verts - len(mesh_obj.data.vertices)
    removed_faces = initial_faces - len(mesh_obj.data.polygons)
    return removed_verts, removed_faces


def ensure_smooth_shading(target_obj, angle_deg=35.0):
    """Universal smooth shading for Blender 3.6 to 5.x."""
    if target_obj.type != 'MESH':
        return

    for poly in target_obj.data.polygons:
        poly.use_smooth = True

    if hasattr(target_obj.data, "use_auto_smooth"):
        target_obj.data.use_auto_smooth = True
        target_obj.data.auto_smooth_angle = math.radians(angle_deg)


def find_existing_cage(target_obj):
    """Finds attached cage if present."""
    for mod in target_obj.modifiers:
        if mod.type == 'DATA_TRANSFER' and mod.object:
            if "_PRO_Cage" in mod.object.name or "_NormalCage" in mod.object.name:
                return mod.object
    return None


def clean_object_cage(target_obj):
    """Cleans up cage object and associated modifiers."""
    cage = find_existing_cage(target_obj)
    for mod_name in ["NormalHealer_Transfer", "NormalHealer_Weighted", "NormalHealer_SeamBevel"]:
        mod = target_obj.modifiers.get(mod_name)
        if mod:
            target_obj.modifiers.remove(mod)

    if cage:
        mesh_data = cage.data
        bpy.data.objects.remove(cage, do_unlink=True)
        if mesh_data and mesh_data.users == 0:
            bpy.data.meshes.remove(mesh_data)
