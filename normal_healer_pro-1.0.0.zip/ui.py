import bpy
from . import operators


class NORMALHEALER_PRO_PT_panel(bpy.types.Panel):
    """Main NormalHealer PRO panel in 3D Viewport Sidebar"""
    bl_label = "Normal Healer PRO"
    bl_idname = "NORMALHEALER_PRO_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Normal Healer PRO"

    def draw(self, context):
        layout = self.layout

        # --- Section 1: Boolean Cuts & Batching ---
        box = layout.box()
        box.label(text="Smart Boolean Operations", icon='MOD_BOOLEAN')
        
        col = box.column(align=True)
        col.scale_y = 1.3
        col.operator("normalhealer_pro.smart_cut", text="Smart Cut & Heal", icon='MOD_BOOLEAN')
        
        col_batch = box.column(align=True)
        col_batch.operator("normalhealer_pro.batch_cut", text="Batch Multi-Cut (PRO)", icon='DUPLICATE')
        col_batch.operator("normalhealer_pro.heal_existing", text="Heal Existing Shading", icon='AUTOMERGE_ON')

        # --- Section 2: Mesh Topology Cleaner (PRO) ---
        box = layout.box()
        box.label(text="Mesh Doctor & Cleaner (PRO)", icon='BRUSH_DATA')
        col_clean = box.column(align=True)
        col_clean.operator("normalhealer_pro.clean_topology", text="Dissolve Degenerate & Doubles", icon='MESH_DATA')

        # --- Section 3: Universal Auto Smooth ---
        box = layout.box()
        box.label(text="Universal Auto Smooth", icon='MOD_SMOOTH')
        row = box.row(align=True)
        row.scale_y = 1.2
        row.operator("normalhealer_pro.autosmooth", text="Auto Smooth (35°)", icon='NORMALS_FACE').angle = 35.0
        row.operator("normalhealer_pro.autosmooth", text="60°", icon='NORMALS_FACE').angle = 60.0

        # --- Section 4: Diagnostics ---
        box = layout.box()
        box.label(text="Surface Quality Check", icon='SHADING_RENDERED')
        box.operator("normalhealer_pro.toggle_diagnostic", text="Toggle Zebra / Flow MatCap", icon='SHADING_TEXTURE')

        # --- Section 5: Bake & Export ---
        box = layout.box()
        box.label(text="Game-Ready Finalize", icon='CHECKMARK')
        box.operator("normalhealer_pro.bake_and_purge", text="Bake & Purge Cages", icon='FILE_TICK')

        # --- Section 6: Author & Priority Support ---
        box_supp = layout.box()
        box_supp.label(text="Author: Integral", icon='SOLO_ON')
        box_supp.operator("normalhealer_pro.open_support", text="VIP Priority Support", icon='HELP')



class NORMALHEALER_PRO_MT_pie_menu(bpy.types.Menu):
    """Quick Pie Menu for NormalHealer PRO (Shift + Alt + N)"""
    bl_label = "Normal Healer PRO Quick Menu"
    bl_idname = "NORMALHEALER_PRO_MT_pie_menu"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()

        # Left
        pie.operator("normalhealer_pro.heal_existing", text="Heal Shading", icon='AUTOMERGE_ON')
        # Right
        pie.operator("normalhealer_pro.smart_cut", text="Smart Cut (PRO)", icon='MOD_BOOLEAN')
        # Bottom
        pie.operator("normalhealer_pro.clean_topology", text="Clean Topology", icon='MESH_DATA')
        # Top
        pie.operator("normalhealer_pro.batch_cut", text="Batch Multi-Cut", icon='DUPLICATE')


def draw_context_menu(self, context):
    layout = self.layout
    layout.separator()
    layout.menu("NORMALHEALER_PRO_MT_pie_menu", text="Normal Healer PRO", icon='MOD_BOOLEAN')
