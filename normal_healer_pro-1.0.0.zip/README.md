# 💎 NormalHealer PRO: Hard Surface & Boolean Suite for Blender

> **The ultimate hard-surface normal projection & live boolean workflow for Blender.**

---

## 🚀 Free vs. PRO Feature Comparison

| Feature | Free Version | PRO Version |
| :--- | :---: | :---: |
| **Smart Boolean & Normal Cage** | ✅ (Single) | ✅ (Single & Batch) |
| **Artifact-Free Curved Cuts** | ✅ | ✅ |
| **Live Rounded Seam Bevel** | ❌ | ✅ **Yes** |
| **Batch Multi-Cutter Array** | ❌ | ✅ **Yes** |
| **Mesh Doctor & Topology Cleaner** | ❌ | ✅ **Yes** |
| **Degenerate Edge & Double Dissolve** | ❌ | ✅ **Yes** |
| **Universal Auto Smooth (35° / 60°)** | ✅ | ✅ |
| **Surface Flow Zebra Diagnostic** | ✅ | ✅ |
| **Game-Ready Bake & Purge** | ✅ | ✅ |

---

## 🛠️ PRO Features Deep-Dive

### 1. 🔲 Live Seam Beveling
Traditional Bevel modifiers after Booleans pinch normals and produce dark streaks. **NormalHealer PRO** positions a live non-destructive rounded bevel directly on the cut seam and projects the un-cut cage curvature over it—giving CAD/NURBS quality fillets in polygonal modeling.

### 2. ⚡ Batch Multi-Cut & Heal
Select 1 target and 10 cutters (bolts, panel insets, ventilation slots, complex cutouts) $\rightarrow$ one click processes all cutters, links their wireframes, and protects the surface normals with a unified reference cage.

### 3. 🧹 Mesh Doctor & Topology Cleaner
Boolean cuts often produce overlapping duplicate vertices and micro-edges with near-zero length that cause shading artifacts in Unreal Engine or Unity. The PRO cleaner automatically dissolves degenerate geometry and merges doubles safely with custom distance thresholds.

---

## 📦 Installation (Blender 4.2+ / 5.x)

1. Open Blender $\rightarrow$ **Edit > Preferences > Get Extensions**.
2. Click top-right dropdown $\rightarrow$ **Install from Disk...**
3. Select `normal_healer_pro-1.0.0.zip` (or `normal_healer_pro.zip`).

---

## 🎮 Shortcut
* **`Shift + Alt + N`** opens the quick Pie Menu.
* **N-Panel**: `3D Viewport > Sidebar (N) > Normal Healer PRO`.

---

## 📬 Author & Priority Support

* **Developer:** Integral
* **VIP Priority Support Email:** [integral7535@gmail.com](mailto:integral7535@gmail.com)
* **Copyright:** © 2026 Integral. All Rights Reserved / GPL-3.0-or-later.


