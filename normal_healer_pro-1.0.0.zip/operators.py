import bpy
from . import utils


class NORMALHEALER_OT_pro_smart_cut(bpy.types.Operator):
    """(PRO) Boolean cut with live seam bevel and instant curvature normal projection"""
    bl_idname = "normalhealer_pro.smart_cut"
    bl_label = "Smart Cut & Heal (PRO)"
    bl_options = {'REGISTER', 'UNDO'}

    operation: bpy.props.EnumProperty(
        name="Operation",
        items=[
            ('DIFFERENCE', "Difference", "Subtract cutter from target"),
            ('UNION', "Union", "Combine cutter and target"),
            ('INTERSECT', "Intersect", "Keep overlapping volume"),
        ],
        default='DIFFERENCE'
    )

    enable_seam_bevel: bpy.props.BoolProperty(
        name="Add Live Seam Bevel",
        description="Add a smooth rounded bevel modifier to the cut seam",
        default=True
    )

    bevel_width: bpy.props.FloatProperty(
        name="Bevel Width",
        description="Width of the rounded cut edge",
        default=0.015,
        min=0.0001,
        max=1.0,
        unit='LENGTH'
    )

    @classmethod
    def poll(cls, context):
        selected = context.selected_objects
        return len(selected) >= 2 and context.active_object in selected and context.active_object.type == 'MESH'

    def execute(self, context):
        target = context.active_object
        selected = [obj for obj in context.selected_objects if obj != target and obj.type == 'MESH']

        if not selected:
            self.report({'ERROR'}, "Select at least one cutter mesh in addition to the active target.")
            return {'CANCELLED'}

        cutter = selected[0]

        # 1. Cage snapshot
        existing_cage = utils.find_existing_cage(target)
        if not existing_cage:
            cage = utils.create_normal_cage(target)
        else:
            cage = existing_cage

        # 2. Boolean modifier
        bool_name = f"Bool_{cutter.name}"
        bool_mod = target.modifiers.get(bool_name)
        if not bool_mod:
            bool_mod = target.modifiers.new(name=bool_name, type='BOOLEAN')

        bool_mod.object = cutter
        bool_mod.operation = self.operation
        bool_mod.solver = 'EXACT'

        cutter.display_type = 'WIRE'
        cutter.hide_render = True

        # 3. Optional PRO Seam Bevel
        if self.enable_seam_bevel:
            utils.setup_seam_bevel(target, width=self.bevel_width, segments=3)

        # 4. Data Transfer & Weighted Normal
        utils.setup_data_transfer(target, cage)
        utils.setup_weighted_normal(target)
        utils.ensure_smooth_shading(target)

        self.report({'INFO'}, f"PRO Smart Cut applied on '{target.name}'.")
        return {'FINISHED'}


class NORMALHEALER_OT_pro_batch_cut(bpy.types.Operator):
    """(PRO) Cut multiple selected objects simultaneously with unified normal projection"""
    bl_idname = "normalhealer_pro.batch_cut"
    bl_label = "Batch Multi-Cut & Heal"
    bl_options = {'REGISTER', 'UNDO'}

    operation: bpy.props.EnumProperty(
        name="Operation",
        items=[
            ('DIFFERENCE', "Difference", "Subtract all cutters"),
            ('UNION', "Union", "Combine all cutters"),
        ],
        default='DIFFERENCE'
    )

    @classmethod
    def poll(cls, context):
        selected = [obj for obj in context.selected_objects if obj.type == 'MESH']
        return len(selected) >= 2 and context.active_object in selected

    def execute(self, context):
        target = context.active_object
        cutters = [obj for obj in context.selected_objects if obj != target and obj.type == 'MESH']

        if not cutters:
            self.report({'ERROR'}, "No valid cutter meshes found.")
            return {'CANCELLED'}

        # Snapshot cage before applying any cuts
        existing_cage = utils.find_existing_cage(target)
        if not existing_cage:
            cage = utils.create_normal_cage(target)
        else:
            cage = existing_cage

        for cutter in cutters:
            bool_name = f"Bool_{cutter.name}"
            bool_mod = target.modifiers.get(bool_name)
            if not bool_mod:
                bool_mod = target.modifiers.new(name=bool_name, type='BOOLEAN')
            bool_mod.object = cutter
            bool_mod.operation = self.operation
            bool_mod.solver = 'EXACT'

            cutter.display_type = 'WIRE'
            cutter.hide_render = True

        utils.setup_data_transfer(target, cage)
        utils.setup_weighted_normal(target)
        utils.ensure_smooth_shading(target)

        self.report({'INFO'}, f"Batch cut {len(cutters)} object(s) into '{target.name}'.")
        return {'FINISHED'}


class NORMALHEALER_OT_pro_clean_topology(bpy.types.Operator):
    """(PRO) Dissolve degenerate micro-edges and merge overlapping vertices for game export"""
    bl_idname = "normalhealer_pro.clean_topology"
    bl_label = "Clean Mesh Topology (PRO)"
    bl_options = {'REGISTER', 'UNDO'}

    merge_dist: bpy.props.FloatProperty(
        name="Merge Distance",
        description="Distance threshold to merge duplicate vertices",
        default=0.0001,
        min=0.00001,
        max=0.01,
        precision=5,
        unit='LENGTH'
    )

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'

    def execute(self, context):
        target = context.active_object
        v_removed, f_removed = utils.clean_mesh_topology(target, merge_dist=self.merge_dist)
        self.report({'INFO'}, f"Cleaned topology: Removed {v_removed} vertices, {f_removed} degenerate faces.")
        return {'FINISHED'}


class NORMALHEALER_OT_pro_heal_existing(bpy.types.Operator):
    """(PRO) Heal shading on complex meshes with multiple existing booleans"""
    bl_idname = "normalhealer_pro.heal_existing"
    bl_label = "Heal Existing Shading (PRO)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'

    def execute(self, context):
        target = context.active_object
        bool_mods = [m for m in target.modifiers if m.type == 'BOOLEAN']

        if bool_mods:
            states = [m.show_viewport for m in bool_mods]
            for m in bool_mods:
                m.show_viewport = False

            cage = utils.create_normal_cage(target)

            for m, state in zip(bool_mods, states):
                m.show_viewport = state

            utils.setup_data_transfer(target, cage)
            utils.setup_weighted_normal(target)
            utils.ensure_smooth_shading(target)
            self.report({'INFO'}, f"PRO Shading healed on '{target.name}'.")
        else:
            bpy.ops.mesh.customdata_custom_splitnormals_clear()
            utils.setup_weighted_normal(target)
            utils.ensure_smooth_shading(target)
            self.report({'INFO'}, f"Split normals recalculated on '{target.name}'.")

        return {'FINISHED'}


class NORMALHEALER_OT_pro_autosmooth(bpy.types.Operator):
    """(PRO) Universal angle auto-smooth across all selected meshes"""
    bl_idname = "normalhealer_pro.autosmooth"
    bl_label = "Universal Auto Smooth (PRO)"
    bl_options = {'REGISTER', 'UNDO'}

    angle: bpy.props.FloatProperty(
        name="Angle (Degrees)",
        default=35.0,
        min=0.0,
        max=180.0
    )

    def execute(self, context):
        count = 0
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                utils.ensure_smooth_shading(obj, angle_deg=self.angle)
                count += 1
        self.report({'INFO'}, f"Auto-smoothed {count} mesh(es) at {self.angle:.1f}°.")
        return {'FINISHED'}


class NORMALHEALER_OT_pro_toggle_diagnostic(bpy.types.Operator):
    """(PRO) Toggle Zebra reflection MatCap to inspect surface flow"""
    bl_idname = "normalhealer_pro.toggle_diagnostic"
    bl_label = "Inspect Surface Flow (PRO)"
    bl_options = {'REGISTER'}

    def execute(self, context):
        shading = context.space_data.shading
        if shading.type != 'SOLID':
            shading.type = 'SOLID'

        if shading.light == 'MATCAP' and shading.studio_light in ['zebra.exr', 'reflection.exr']:
            shading.light = 'STUDIO'
            self.report({'INFO'}, "Inspection mode turned off.")
        else:
            shading.light = 'MATCAP'
            available = [m.name for m in bpy.context.preferences.studio_lights]
            if "zebra.exr" in available:
                shading.studio_light = "zebra.exr"
            elif "reflection.exr" in available:
                shading.studio_light = "reflection.exr"
            self.report({'INFO'}, "Surface Inspection Mode enabled.")
        return {'FINISHED'}


class NORMALHEALER_OT_pro_bake_and_purge(bpy.types.Operator):
    """(PRO) Finalize all booleans, bevels, and normal transfers into a clean game-ready mesh"""
    bl_idname = "normalhealer_pro.bake_and_purge"
    bl_label = "Bake & Purge Cages (PRO)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'

    def execute(self, context):
        target = context.active_object
        cage = utils.find_existing_cage(target)

        for mod in list(target.modifiers):
            if mod.name in ["NormalHealer_Transfer", "NormalHealer_Weighted", "NormalHealer_SeamBevel"] or mod.type == 'BOOLEAN':
                try:
                    bpy.ops.object.modifier_apply(modifier=mod.name)
                except Exception as e:
                    self.report({'WARNING'}, f"Could not apply modifier {mod.name}: {e}")

        if cage:
            utils.clean_object_cage(target)

        self.report({'INFO'}, f"PRO baked and cages purged for '{target.name}'.")
        return {'FINISHED'}


class NORMALHEALER_PRO_OT_open_support(bpy.types.Operator):
    """Contact developer for VIP priority support, feature requests, or questions"""
    bl_idname = "normalhealer_pro.open_support"
    bl_label = "Priority Support"
    bl_options = {'REGISTER'}

    def execute(self, context):
        support_url = "mailto:integral7535@gmail.com?subject=NormalHealer%20PRO%20Priority%20Support"
        bpy.ops.wm.url_open(url=support_url)
        self.report({'INFO'}, "Opening support email to integral7535@gmail.com")
        return {'FINISHED'}

