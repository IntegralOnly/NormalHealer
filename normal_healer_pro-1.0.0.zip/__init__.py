bl_info = {
    "name": "NormalHealer PRO: Hard Surface & Boolean Suite",
    "author": "Integral",
    "version": (1, 0, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Normal Healer PRO & Shift+Alt+N",
    "description": "Pro hard-surface boolean suite with live bevels, batch cutting, and normal cages.",
    "doc_url": "mailto:integral7535@gmail.com",
    "tracker_url": "mailto:integral7535@gmail.com",
    "support": "COMMUNITY",
    "category": "Mesh",
}

import bpy
from . import operators
from . import ui

classes = (
    operators.NORMALHEALER_OT_pro_smart_cut,
    operators.NORMALHEALER_OT_pro_batch_cut,
    operators.NORMALHEALER_OT_pro_clean_topology,
    operators.NORMALHEALER_OT_pro_heal_existing,
    operators.NORMALHEALER_OT_pro_autosmooth,
    operators.NORMALHEALER_OT_pro_toggle_diagnostic,
    operators.NORMALHEALER_OT_pro_bake_and_purge,
    operators.NORMALHEALER_PRO_OT_open_support,
    ui.NORMALHEALER_PRO_PT_panel,
    ui.NORMALHEALER_PRO_MT_pie_menu,
)

addon_keymaps = []


def register_keymaps():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if not kc:
        return

    km = kc.keymaps.new(name="3D View", space_type='VIEW_3D')
    kmi = km.keymap_items.new("wm.call_menu_pie", type='N', value='PRESS', shift=True, alt=True)
    kmi.properties.name = "NORMALHEALER_PRO_MT_pie_menu"
    addon_keymaps.append((km, kmi))


def unregister_keymaps():
    for km, kmi in addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    addon_keymaps.clear()


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.VIEW3D_MT_object_context_menu.append(ui.draw_context_menu)
    register_keymaps()


def unregister():
    unregister_keymaps()
    bpy.types.VIEW3D_MT_object_context_menu.remove(ui.draw_context_menu)

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
